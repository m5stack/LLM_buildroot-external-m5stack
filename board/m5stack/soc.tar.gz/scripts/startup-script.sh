#!/bin/sh
if [ ! -f '/soc/scripts/.check' ] ; then
    for file in /soc/scripts/*.sh; do
        if [ -f "$file" ]; then
            sed -i 's/^\s*function\s\+\([a-zA-Z_][a-zA-Z0-9_]*\)\s*()/\1()/' "$file"
        fi
    done
    touch /soc/scripts/.check
fi

/soc/scripts/auto_load_all_drv.sh
mkdir -p /opt/data/AXSyslog/kernel

/soc/scripts/axemac.sh

chmod 755 /soc/scripts/npu_set_bw_limiter.sh
/soc/scripts/npu_set_bw_limiter.sh start

/soc/scripts/axsyslogd start
/soc/scripts/axklogd start
chmod 755 /soc/scripts/S99checkboot
/soc/scripts/S99checkboot systemA
chmod 755 /soc/scripts/S99checkota
/soc/scripts/S99checkota start

exit 0