#!/bin/sh
mkdir -p /opt/data/AXSyslog/kernel

/soc/scripts/axemac.sh

chmod 755 /soc/scripts/npu_set_bw_limiter.sh
/soc/scripts/npu_set_bw_limiter.sh start

/soc/scripts/axsyslogd start
/soc/scripts/axklogd start
chmod 755 /soc/scripts/S99checkboot
/soc/scripts/S99checkboot systemA
chmod 755 /soc/scripts/S99checkota
/soc/scripts/S99checkota start

exit 0